// Home.js
import React from 'react';

function Home(props) {
  const { formData } = props.location.state;

  return (
    <div>
      <h2>Home Component</h2>
      <p>Name: {formData.name}</p>
      <p>Age: {formData.age}</p>
      <p>Address: {formData.address}</p>
      <p>Email: {formData.email}</p>
    </div>
  );
}

export default Home;
